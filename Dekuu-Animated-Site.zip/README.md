# Dekuu — Animated Static Site

Pages
- `index.html` — Home
- `login.html` — Login (demo auth)
- `signup.html` — Sign up (demo auth)
- `profile.html` — Profile (requires demo login)
- `info.html` — Info (renders `posts.json`)
- `blog.html` — Blog (renders `posts.json`)
- `contact.html` — Contact (mailto to mujtaba819best@gmail.com)

Deploy on GitHub Pages
1. Upload these files to a repo.
2. Settings → Pages → Deploy from a branch → Branch: main → Folder: /(root).

Contact Backend
- Currently mailto to mujtaba819best@gmail.com.
- To use Formspree: create a Formspree form, then replace onContact in assets/app.js with a fetch() POST to your form endpoint.
